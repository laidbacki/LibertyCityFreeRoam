Liberty-City_FreeRoam
A Liberty City free-roam Server base for FiveM | NO SQL |

-This is inspired to Gta IV Multiplayer FreeRoam.

How to start: Add Steam API Key in Server.cfg | Add Keymaster Key in Server.cfg | Modify ServerStart.bat with your Server Directory. | No database needed, ENJOY!

SERVER START/JOIN TAKES A LOT THE FIRST TIME.

/help to see all the useful commands /rules to see server rules

It contains:

Full Liberty City Map with working Traffic and working Dispatch (Unloaded Los Santos map)
vMenu with lot of GTA IV Add-On Vehicles
Working Phone
No Lag
VisualSettings, Removed FOG
Taxi System (F7) [[Little bug: drivers blind af]]
Gta IV Vehicles Handling & Realistic Damage
Working Sirens on ELS (G) | Realistic Brake Lights | Realistic Air Control
Gta IV Ragdoll System
Real Weapons
NO SQL/DATABASE NEEDED!
NO STEAM NEEDED TO JOIN
Known Bugs: Teleport with vMenu may cause crash.

Credits for the Map: CJ, Math, PichotM, Vladi Boy, Ly, njkellman, ER

**THIS SERVER IS BASED ON VENOMOUS ON BASIC FREE-ROAM PROJECT By Ghermans | https://github.com/FiveM-Scripts/venomous-freemode




**************INSTALLATION****************

NEED TO DO CONFIGURE THE "SERVER.CFG":

- CHANGE (Line 7 | AT THE TOP) WITH YOUR DIRECTORY
*EXAMPLE*: 
 *exec C:\YOURDIRECTORY\LibertyV_freeroam\server-data\resources\[system]\vMenu\config\permissions.cfg*

- SET (LINE 136 | AT THE BOTTOM) YOUR STEAM WEB API KEY. (You can find it on your Steam's profile data)

- SET (LINE 139 | ENDING LINE) YOUR FIVEM LICENSE KEY. (You can create it trough the Fivem Keymaster)


***TO START YOU SERVER***

YOU NEED TO MODIFY THE "Start.bat" file in the main folder and change it with your DIRECTORY.

*EXAMPLE*:
cd /d C:\YOURDIRECTORY\LibertyV_freeroam\server-data
C:\YOURDIRECTORY\LibertyV_freeroam\FXServer.exe +exec server.cfg

CHANGE "YOURDIRECTORY" with your specific directory


START & PLAY without DataBase, enjoy!